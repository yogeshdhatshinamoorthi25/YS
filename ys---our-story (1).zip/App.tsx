
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Heart, ChevronRight, ChevronLeft, CheckCircle2, Lock, Unlock, Camera, Plus, Trash2, Image as ImageIcon, MapPin, Calendar, CheckSquare, Square, ExternalLink } from 'lucide-react';
import confetti from 'canvas-confetti';
import { LOVE_MESSAGES, TIMELINE_DATA } from './constants';
import FloatingHearts from './components/FloatingHearts';

// --- Types ---
enum Screen {
  GATE = 1,
  WELCOME = 2,
  TIMELINE = 3,
  GALLERY = 4,
  REVEAL = 5,
  PROPOSAL = 6,
  DATES = 7
}

interface DateSuggestion {
  id: string;
  name: string;
  location: string;
  dateAdded: string;
  visited: boolean;
}

// --- Helper: Image Compression ---
const compressImage = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 800;
        let width = img.width;
        let height = img.height;
        if (width > MAX_WIDTH) {
          height *= MAX_WIDTH / width;
          width = MAX_WIDTH;
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
        resolve(dataUrl);
      };
    };
    reader.onerror = reject;
  });
};

// --- Animation Components ---
const FadeIn: React.FC<{ children: React.ReactNode; className?: string; delay?: number }> = ({ children, className, delay = 0 }) => {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), delay);
    return () => clearTimeout(timer);
  }, [delay]);
  return (
    <div className={`transition-all duration-1000 transform ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'} ${className}`}>
      {children}
    </div>
  );
};

// --- Main App ---
const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>(Screen.GATE);
  const [gateStep, setGateStep] = useState(1);
  const [yearInput, setYearInput] = useState('');
  const [cityInput, setCityInput] = useState('');
  const [gateError, setGateError] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [randomMessage, setRandomMessage] = useState<string | null>(null);
  const [randomImageIndex, setRandomImageIndex] = useState<number | null>(null);
  const [proposalStatus, setProposalStatus] = useState<'pending' | 'yes' | 'always'>('pending');
  const [galleryImages, setGalleryImages] = useState<string[]>([]);
  const [dateSuggestions, setDateSuggestions] = useState<DateSuggestion[]>([]);
  const [isIframe, setIsIframe] = useState(false);
  
  const [newPlaceName, setNewPlaceName] = useState('');
  const [newPlaceLocation, setNewPlaceLocation] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Check if running inside AI Studio iframe
    setIsIframe(window.self !== window.top);

    const savedImages = localStorage.getItem('ys_gallery_images');
    if (savedImages) {
      try { setGalleryImages(JSON.parse(savedImages)); } catch (e) { console.error(e); }
    }
    const savedDates = localStorage.getItem('ys_date_suggestions');
    if (savedDates) {
      try { setDateSuggestions(JSON.parse(savedDates)); } catch (e) { console.error(e); }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('ys_gallery_images', JSON.stringify(galleryImages));
  }, [galleryImages]);

  useEffect(() => {
    localStorage.setItem('ys_date_suggestions', JSON.stringify(dateSuggestions));
  }, [dateSuggestions]);

  const handleGateSubmit = () => {
    setGateError('');
    const normalizedYear = yearInput.trim();
    const normalizedCity = cityInput.trim().toLowerCase();
    if (gateStep === 1) {
      if (normalizedYear === '2022') setGateStep(2);
      else setGateError('Hmm… try again. Think about when everything changed 🌸');
    } else if (gateStep === 2) {
      if (normalizedCity === 'grenoble') {
        setIsAdmin(false);
        setIsUnlocked(true);
        setTimeout(() => setCurrentScreen(Screen.WELCOME), 3500);
      } else if (normalizedCity === 'madurai') {
        setIsAdmin(true);
        setIsUnlocked(true);
        setTimeout(() => setCurrentScreen(Screen.WELCOME), 3500);
      } else {
        setGateError('Not quite… think about the city where destiny worked overtime 🚲');
      }
    }
  };

  const handleBack = () => {
    setGateError('');
    if (currentScreen === Screen.GATE) {
      if (gateStep === 2) setGateStep(1);
    } else if (currentScreen === Screen.WELCOME) {
      setIsUnlocked(false);
      setGateStep(2);
      setCurrentScreen(Screen.GATE);
    } else if (currentScreen === Screen.TIMELINE) {
      setCurrentScreen(Screen.WELCOME);
    } else if (currentScreen === Screen.GALLERY) {
      setCurrentScreen(Screen.TIMELINE);
    } else if (currentScreen === Screen.REVEAL) {
      setCurrentScreen(Screen.GALLERY);
    } else if (currentScreen === Screen.PROPOSAL) {
      if (proposalStatus !== 'pending') setProposalStatus('pending');
      else setCurrentScreen(Screen.REVEAL);
    } else if (currentScreen === Screen.DATES) {
      setCurrentScreen(Screen.PROPOSAL);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const newImages: string[] = [];
    for (let i = 0; i < files.length; i++) {
      try {
        const compressed = await compressImage(files[i]);
        newImages.push(compressed);
      } catch (err) { console.error(err); }
    }
    setGalleryImages(prev => [...prev, ...newImages]);
  };

  const deleteImage = (index: number) => {
    setGalleryImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleShowRandomMessage = useCallback(() => {
    const randomMsgIndex = Math.floor(Math.random() * LOVE_MESSAGES.length);
    setRandomMessage(LOVE_MESSAGES[randomMsgIndex]);
    if (galleryImages.length > 0) {
      const randomImgIdx = Math.floor(Math.random() * galleryImages.length);
      setRandomImageIndex(randomImgIdx);
    }
  }, [galleryImages]);

  const triggerConfetti = (isAlways: boolean) => {
    const duration = isAlways ? 5 * 1000 : 3 * 1000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };
    const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;
    const interval: any = setInterval(function() {
      const timeLeft = animationEnd - Date.now();
      if (timeLeft <= 0) return clearInterval(interval);
      const particleCount = 50 * (timeLeft / duration);
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
    }, 250);
  };

  const handleProposal = (choice: 'yes' | 'always') => {
    setProposalStatus(choice);
    triggerConfetti(choice === 'always');
  };

  const handleAddDate = () => {
    if (!newPlaceName.trim()) return;
    const newDate: DateSuggestion = {
      id: Date.now().toString(),
      name: newPlaceName,
      location: newPlaceLocation || 'Location TBD',
      dateAdded: new Date().toLocaleDateString(),
      visited: false
    };
    setDateSuggestions(prev => [newDate, ...prev]);
    setNewPlaceName('');
    setNewPlaceLocation('');
  };

  const toggleVisited = (id: string) => {
    setDateSuggestions(prev => prev.map(d => d.id === id ? { ...d, visited: !d.visited } : d));
  };

  const deleteDate = (id: string) => {
    setDateSuggestions(prev => prev.filter(d => d.id !== id));
  };

  return (
    <div className="relative min-h-screen w-full font-sans bg-[#FFF5F7] select-none touch-manipulation">
      <FloatingHearts />
      
      {((currentScreen === Screen.GATE && gateStep > 1 && !isUnlocked) || (currentScreen > Screen.GATE)) && (
        <button 
          onClick={handleBack}
          className="fixed top-6 left-6 z-50 flex items-center gap-1 text-pink-300 hover:text-pink-500 transition-colors font-sans font-medium text-sm group p-2"
        >
          <ChevronLeft className="w-5 h-5 transform group-hover:-translate-x-1 transition-transform" />
          Back
        </button>
      )}

      <div className="relative z-10 w-full min-h-screen flex flex-col overflow-x-hidden">
        
        {currentScreen === Screen.GATE && (
          <div className="flex flex-col items-center justify-center min-h-screen p-6 text-center">
            {!isUnlocked ? (
              <FadeIn className="w-full max-w-md">
                {isIframe && (
                  <div className="mb-6 p-4 bg-pink-100 rounded-2xl text-pink-600 text-xs flex items-center justify-between shadow-sm animate-pulse border border-pink-200">
                    <span className="text-left font-medium pr-4">To install properly, tap the "Open in new tab" icon at the top right first.</span>
                    <ExternalLink className="w-5 h-5 flex-shrink-0" />
                  </div>
                )}
                <div className="mb-8 flex justify-center">
                  <div className="p-4 bg-white rounded-full shadow-soft-pink">
                    <Lock className="w-8 h-8 text-pink-300" />
                  </div>
                </div>
                <h1 className="text-3xl font-serif mb-2 text-gray-800 italic">Only one person can enter this story…</h1>
                <p className="text-pink-400 mb-10 text-sm tracking-wide uppercase font-sans font-medium">This space belongs to us 💞</p>
                
                <div className="bg-white/80 backdrop-blur-sm p-8 rounded-3xl shadow-xl border border-pink-100">
                  <div className="space-y-6">
                    {gateStep === 1 ? (
                      <>
                        <label className="block text-gray-600 font-sans text-lg">Since what year have we been writing our story?</label>
                        <input 
                          type="number" 
                          inputMode="numeric"
                          autoFocus
                          value={yearInput}
                          onChange={(e) => setYearInput(e.target.value)}
                          placeholder="YYYY"
                          className="w-full p-4 rounded-xl border-pink-200 border-2 focus:outline-none focus:border-pink-400 text-center text-xl text-gray-700 font-sans transition-all"
                        />
                      </>
                    ) : (
                      <div className="animate-[fadeIn_0.5s_ease-out]">
                        <label className="block text-gray-600 font-sans text-lg">Where did our story begin?</label>
                        <input 
                          type="text" 
                          autoFocus
                          value={cityInput}
                          onChange={(e) => setCityInput(e.target.value)}
                          placeholder="Enter city..."
                          className="w-full p-4 mt-6 rounded-xl border-pink-200 border-2 focus:outline-none focus:border-pink-400 text-center text-xl text-gray-700 font-sans transition-all"
                        />
                      </div>
                    )}
                  </div>
                  {gateError && <p className="mt-4 text-red-400 text-sm italic animate-pulse">{gateError}</p>}
                  <button 
                    onClick={handleGateSubmit}
                    className="mt-8 w-full bg-pink-400 hover:bg-pink-500 text-white font-sans font-bold py-4 rounded-xl transition-all shadow-lg active:scale-95 transform"
                  >
                    Continue
                  </button>
                </div>
              </FadeIn>
            ) : (
              <div className="fixed inset-0 bg-white/60 backdrop-blur-sm flex items-center justify-center z-50">
                <FadeIn className="text-center p-10 bg-white rounded-[3rem] shadow-2xl border border-pink-200 mx-6">
                   <div className="mb-6 flex justify-center">
                    <Unlock className="w-16 h-16 text-green-400 animate-bounce" />
                  </div>
                  <h2 className="text-3xl font-serif text-gray-800 mb-4">{isAdmin ? 'Admin' : 'Access'} granted to Murugesa</h2>
                  <p className="text-gray-600 text-lg mb-6">Lifetime membership approved.</p>
                  <div className="space-y-2 italic text-pink-400 text-sm">
                    <p>Since 2022.</p>
                    <p>Since {cityInput}.</p>
                    <p>Since you.</p>
                  </div>
                </FadeIn>
              </div>
            )}
          </div>
        )}

        {currentScreen === Screen.WELCOME && (
          <div className="flex flex-col items-center justify-center min-h-screen p-6 text-center">
            <FadeIn className="max-w-md">
              <h1 className="text-5xl font-serif mb-8 text-gray-800">Hi Murugesa 🌷</h1>
              <div className="space-y-6 text-lg text-gray-600 leading-relaxed font-sans mb-12 px-4">
                <p>Since 2022… my life has been different.</p>
                <p>Better. Softer. Happier.</p>
                <p>I didn’t just build this app.</p>
                <p className="font-medium text-pink-500 italic">I built this for you.</p>
              </div>
              <button 
                onClick={() => setCurrentScreen(Screen.TIMELINE)}
                className="flex items-center gap-2 mx-auto bg-pink-400 text-white font-sans font-bold px-10 py-5 rounded-full shadow-lg active:scale-95 transition-transform"
              >
                Begin Our Story <ChevronRight className="w-5 h-5" />
              </button>
            </FadeIn>
          </div>
        )}

        {currentScreen === Screen.TIMELINE && (
          <div className="min-h-screen p-6 pb-32 max-w-2xl mx-auto flex flex-col pt-16">
            <FadeIn>
              <h2 className="text-4xl font-serif text-center mb-12 text-gray-800">Our Journey</h2>
              <div className="space-y-8">
                {TIMELINE_DATA.map((item, idx) => (
                  <FadeIn key={idx} delay={idx * 200} className="bg-white p-6 rounded-[2rem] shadow-sm border border-pink-50">
                    <h3 className="text-xl font-serif text-pink-500 mb-3">{item.title}</h3>
                    <p className="text-gray-600 leading-relaxed font-sans text-sm md:text-base">{item.text}</p>
                  </FadeIn>
                ))}
              </div>
              <div className="mt-16 flex flex-col gap-4 items-center">
                <button 
                  onClick={() => setCurrentScreen(Screen.GALLERY)}
                  className="w-full max-w-xs bg-white border-2 border-pink-200 text-pink-500 font-sans font-bold py-4 rounded-full flex items-center justify-center gap-2 shadow-sm active:scale-95 transition-transform"
                >
                  <ImageIcon className="w-5 h-5" /> Our Gallery
                </button>
                <button 
                  onClick={() => setCurrentScreen(Screen.REVEAL)}
                  className="w-full max-w-xs bg-pink-400 text-white font-sans font-bold py-4 rounded-full flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-transform"
                >
                  Why I Love You <Heart className="w-5 h-5 fill-current" />
                </button>
              </div>
            </FadeIn>
          </div>
        )}

        {currentScreen === Screen.GALLERY && (
          <div className="min-h-screen p-6 pb-24 pt-20 max-w-4xl mx-auto flex flex-col w-full">
            <FadeIn className="w-full">
              <div className="flex items-center justify-between mb-8 px-2">
                <h2 className="text-3xl font-serif text-gray-800">Captured Moments</h2>
                {isAdmin && (
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="p-3 bg-pink-400 text-white rounded-full shadow-lg active:scale-90 transition-transform"
                  >
                    <Plus className="w-6 h-6" />
                  </button>
                )}
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  multiple 
                  onChange={handleFileUpload}
                />
              </div>
              {galleryImages.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-pink-300">
                  <ImageIcon className="w-16 h-16 mb-4 opacity-20" />
                  <p className="font-sans italic text-center">No memories uploaded yet...</p>
                  {isAdmin && <p className="text-xs mt-2 opacity-60 text-center">Tap the + to add some!</p>}
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4 px-2">
                  {galleryImages.map((img, idx) => (
                    <div key={idx} className="relative group aspect-square overflow-hidden rounded-2xl shadow-md bg-pink-50">
                      <img src={img} alt="Memory" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                      {isAdmin && (
                        <button 
                          onClick={() => deleteImage(idx)}
                          className="absolute top